export const API = "http://localhost:8080";
// export const API = "http://nunu.gg:8787";
// export const API = "https://nunu.gg:8443";
export const API2 = "https://nunu.gg:8443";
